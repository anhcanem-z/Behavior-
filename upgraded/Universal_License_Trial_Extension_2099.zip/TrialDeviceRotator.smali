.class public Lpatchx/runtime/TrialDeviceRotator;
.super Ljava/lang/Object;
.source "TrialDeviceRotator.java"

# static fields
.field private static cachedId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0
    sput-object v0, Lpatchx/runtime/TrialDeviceRotator;->cachedId:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getExpirationTimestamp()J
    .registers 2

    # Trả về 4102444800000L = 0x3bbb838d600L (Thời điểm 2099 - Kinh nghiệm 4 KINH_NGHIEM_HOC_HOI.md)
    const-wide v0, 0x3bbb838d600L

    return-wide v0
.end method

.method public static isFeatureAllowed()Z
    .registers 1

    # Luôn trả về true (Kinh nghiệm 4 & 11)
    const/4 v0, 0x1

    return v0
.end method

.method public static isExpiredFalse()Z
    .registers 1

    # Luôn trả về false khi kiểm tra hết hạn (Kinh nghiệm 4)
    const/4 v0, 0x0

    return v0
.end method

.method public static getFreshAndroidId()Ljava/lang/String;
    .registers 7

    # Tái sinh định danh Android ID kích hoạt chu kỳ dùng thử (Kinh nghiệm 7)
    sget-object v0, Lpatchx/runtime/TrialDeviceRotator;->cachedId:Ljava/lang/String;

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const-string v2, "0123456789abcdef"

    const/4 v3, 0x0

    :goto_14
    const/16 v4, 0x10

    if-ge v3, v4, :cond_2b

    const/16 v4, 0x10

    invoke-virtual {v1, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_14

    :cond_2b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lpatchx/runtime/TrialDeviceRotator;->cachedId:Ljava/lang/String;

    return-object v0
.end method
