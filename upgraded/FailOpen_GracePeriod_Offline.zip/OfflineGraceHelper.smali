.class public Lpatchx/runtime/OfflineGraceHelper;
.super Ljava/lang/Object;
.source "OfflineGraceHelper.java"

# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static isGracePeriodActive()Z
    .registers 1

    const/4 v0, 0x1

    return v0
.end method

.method public static getGraceDays()I
    .registers 1

    const/16 v0, 0x1e

    return v0
.end method
